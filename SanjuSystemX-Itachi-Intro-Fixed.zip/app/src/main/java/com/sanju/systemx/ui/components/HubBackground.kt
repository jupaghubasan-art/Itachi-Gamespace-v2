package com.sanju.systemx.ui.components

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import com.sanju.systemx.ui.Pal

/** Static hub background (black, red glows, slanted HUD lines). Drawn only when needed, no animation. */
class HubBackground(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var glowA: RadialGradient? = null
    private var glowB: RadialGradient? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        glowA = RadialGradient(w * 0.15f, h.toFloat(), w * 0.55f, 0x55E9003C, 0x00E9003C, Shader.TileMode.CLAMP)
        glowB = RadialGradient(w * 0.95f, 0f, w * 0.45f, 0x33E9003C, 0x00E9003C, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(Pal.bg)
        p.style = Paint.Style.FILL
        p.shader = glowA; c.drawRect(0f, 0f, w, h, p)
        p.shader = glowB; c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = 0xFFE9003C.toInt(); p.alpha = 28
        for (i in 0..5) {
            val x = w * (0.08f + 0.17f * i)
            c.drawLine(x, h, x + h * 0.55f, 0f, p)
        }
    }
}
