package com.sanju.systemx.optimizer

import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.sanju.systemx.device.GraphicsInfo
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.shizuku.ShizukuState
import java.io.File

enum class Support { SUPPORTED, LIMITED, UNSUPPORTED }
data class Capability(val name: String, val support: Support, val note: String)

object CapabilityDetector {
    fun detect(a: Activity, sz: ShizukuState?, gfx: GraphicsInfo?): List<Capability> {
        val rates = DisplayCtl.rates(a)
        val b: Intent? = a.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val hasTemp = b?.hasExtra(BatteryManager.EXTRA_TEMPERATURE) == true
        val hasFreq = File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq").runCatching { readText(); true }.getOrDefault(false)
        val unavailable = "Unavailable through public Android API"
        return listOf(
            Capability("Refresh-rate request",
                if (rates.size > 1) Support.LIMITED else Support.UNSUPPORTED,
                if (rates.size > 1) "${rates.joinToString(" / ") { it.hz.toString() }} Hz; applies to the Game Space window only" else "Display reports a single rate"),
            Capability("Resolution scaling",
                if (sz == ShizukuState.CONNECTED) Support.SUPPORTED else Support.UNSUPPORTED,
                if (sz == ShizukuState.CONNECTED) "Via Shizuku (wm size)" else "Needs Shizuku connected"),
            Capability("Game detection & launch", Support.SUPPORTED, "Launcher-app package visibility"),
            Capability("System RAM & battery", Support.SUPPORTED, "Android APIs"),
            Capability("Battery temperature", if (hasTemp) Support.SUPPORTED else Support.UNSUPPORTED, "Battery sensor, not CPU temperature"),
            Capability("CPU frequency", if (hasFreq) Support.LIMITED else Support.UNSUPPORTED, if (hasFreq) "Readable on this device" else "Restricted by Android"),
            Capability("CPU load", Support.UNSUPPORTED, unavailable),
            Capability("GPU utilization", Support.UNSUPPORTED, unavailable),
            Capability("External game FPS", Support.UNSUPPORTED, "Not exposed by Android"),
            Capability("GPU & graphics info", if (gfx?.renderer != null) Support.SUPPORTED else Support.LIMITED, gfx?.renderer ?: "Renderer not readable")
        )
    }
}
