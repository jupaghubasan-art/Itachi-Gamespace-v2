package com.sanju.systemx.gamespace

import com.sanju.systemx.monitor.Monitor
import com.sanju.systemx.settings.Prefs
import java.util.Locale

/**
 * Lightweight session record. Without an overlay permission Android gives no live data while a game is in
 * front, so this stores the start state and reports real before/after values when the user returns.
 */
object GameSessionManager {
    fun begin(p: Prefs, s: Monitor.Sample, g: GameInfo) {
        p.setS("sess_pkg", g.pkg); p.setS("sess_name", g.label)
        p.setL("sess_ts", System.currentTimeMillis())
        p.setI("sess_bat", s.battery); p.setF("sess_temp", s.tempC ?: -100f)
    }

    fun clear(p: Prefs) { p.setS("sess_pkg", "") }

    fun end(p: Prefs, s: Monitor.Sample): String? {
        if (p.getS("sess_pkg", "").isEmpty()) return null
        val mins = (System.currentTimeMillis() - p.getL("sess_ts", 0L)) / 60000
        val name = p.getS("sess_name", "Game")
        val b0 = p.getI("sess_bat", -1); val t0 = p.getF("sess_temp", -100f)
        clear(p)
        if (mins < 1) return null
        val bat = if (b0 >= 0 && s.battery >= 0) "battery $b0% → ${s.battery}%" else "battery n/a"
        val temp = if (t0 > -99f && s.tempC != null) String.format(Locale.US, "temp %.1f → %.1f °C", t0, s.tempC) else "temp n/a"
        return "$name · $mins min · $bat · $temp"
    }
}
