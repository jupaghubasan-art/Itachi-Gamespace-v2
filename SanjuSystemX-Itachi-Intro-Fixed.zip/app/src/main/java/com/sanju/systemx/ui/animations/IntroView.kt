package com.sanju.systemx.ui.animations

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import com.sanju.systemx.R
import kotlin.math.max

/**
 * Five-second Itachi/Sharingan startup cinematic.
 *
 * Timeline:
 * 0.00-0.55  dark fade-in
 * 0.55-2.15  eye slowly opens
 * 2.15-3.20  Sharingan reveal + red pulse
 * 3.20-5.00  hold with subtle breathing/zoom
 */
class IntroView(ctx: Context) : View(ctx) {
    var t = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.itachi_intro)

    // Approximate Sharingan region in the supplied 864x1536 image.
    // The image is center-cropped to the landscape Game Space viewport.
    private val eyeSrc = RectF(355f, 625f, 705f, 925f)

    private fun ease(v: Float): Float {
        val x = v.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }

    private fun lerp(a: Float, b: Float, x: Float) = a + (b - a) * x

    private fun drawCenterCrop(c: Canvas, scaleExtra: Float): RectF {
        val w = width.toFloat()
        val h = height.toFloat()
        val scale = max(w / bitmap.width, h / bitmap.height) * scaleExtra
        val dw = bitmap.width * scale
        val dh = bitmap.height * scale
        val left = (w - dw) * 0.5f
        val top = (h - dh) * 0.5f
        val dst = RectF(left, top, left + dw, top + dh)
        p.alpha = 255
        c.drawBitmap(bitmap, null, dst, p)
        return dst
    }

    private fun mapSourceToDst(src: RectF, dst: RectF): RectF {
        val sx = dst.width() / bitmap.width
        val sy = dst.height() / bitmap.height
        return RectF(
            dst.left + src.left * sx,
            dst.top + src.top * sy,
            dst.left + src.right * sx,
            dst.top + src.bottom * sy
        )
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF000000.toInt())

        // Gentle cinematic zoom that settles during the 5-second hold.
        val zoom = lerp(1.055f, 1.0f, ease(t))
        val imageDst = drawCenterCrop(c, zoom)
        val eye = mapSourceToDst(eyeSrc, imageDst)

        // Opening animation. The image is already the final open Sharingan;
        // black eyelid masks make it visually open from a narrow slit.
        val open = ease(((t - 0.10f) / 0.34f).coerceIn(0f, 1f))
        val centerY = eye.centerY()
        val closedHalf = eye.height() * 0.055f
        val openHalf = eye.height() * 0.50f
        val half = lerp(closedHalf, openHalf, open)

        // Cover the upper/lower parts of the eye with curved black lids.
        val lidTop = Path().apply {
            moveTo(eye.left - eye.width() * 0.18f, eye.top - eye.height() * 0.20f)
            cubicTo(
                eye.left, centerY - half * 0.62f,
                eye.centerX(), centerY - half * 0.82f,
                eye.right + eye.width() * 0.18f, eye.top - eye.height() * 0.20f
            )
            lineTo(eye.right + eye.width() * 0.18f, eye.top - eye.height())
            lineTo(eye.left - eye.width() * 0.18f, eye.top - eye.height())
            close()
        }
        val lidBottom = Path().apply {
            moveTo(eye.left - eye.width() * 0.18f, eye.bottom + eye.height() * 0.20f)
            cubicTo(
                eye.left, centerY + half * 0.62f,
                eye.centerX(), centerY + half * 0.82f,
                eye.right + eye.width() * 0.18f, eye.bottom + eye.height() * 0.20f
            )
            lineTo(eye.right + eye.width() * 0.18f, eye.bottom + eye.height())
            lineTo(eye.left - eye.width() * 0.18f, eye.bottom + eye.height())
            close()
        }
        p.shader = null
        p.color = 0xFF000000.toInt()
        p.alpha = 255
        c.drawPath(lidTop, p)
        c.drawPath(lidBottom, p)

        // Red Sharingan glow starts when the eye reaches the fully-open stage.
        val reveal = ease(((t - 0.42f) / 0.15f).coerceIn(0f, 1f))
        if (reveal > 0f) {
            val pulse = 0.55f + 0.45f * (0.5f + 0.5f * kotlin.math.sin(t * Math.PI * 10.0)).toFloat()
            val radius = eye.width() * 0.72f
            glowPaint.shader = RadialGradient(
                eye.centerX(), eye.centerY(), radius,
                intArrayOf(
                    0x66FF0000,
                    (0x20FF0000 * pulse).toInt(),
                    0x00000000
                ),
                floatArrayOf(0f, 0.42f, 1f),
                Shader.TileMode.CLAMP
            )
            glowPaint.alpha = (255 * reveal).toInt()
            c.drawCircle(eye.centerX(), eye.centerY(), radius, glowPaint)
            glowPaint.shader = null
        }

        // Short cinematic white/red flash exactly around the Sharingan reveal.
        val flash = (1f - ((t - 0.47f) / 0.10f).coerceIn(0f, 1f)) * reveal
        if (flash > 0f) {
            p.color = 0x22FFFFFF
            p.alpha = (255 * flash).toInt()
            c.drawRect(0f, 0f, w, h, p)
        }

        // Keep the eye focused after the reveal with a very subtle vignette.
        val vignette = RadialGradient(
            w * 0.63f, h * 0.53f, max(w, h) * 0.78f,
            intArrayOf(0x00000000, 0xAA000000.toInt()),
            floatArrayOf(0.35f, 1f),
            Shader.TileMode.CLAMP
        )
        p.shader = vignette
        p.alpha = 210
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // Tiny title only after the eye has opened, so the eye remains the hero.
        val titleA = ease(((t - 0.66f) / 0.12f).coerceIn(0f, 1f))
        if (titleA > 0f) {
            p.textAlign = Paint.Align.CENTER
            p.typeface = android.graphics.Typeface.DEFAULT_BOLD
            p.textSize = h * 0.042f
            p.letterSpacing = 0.22f
            p.color = 0xFFFFFFFF.toInt()
            p.alpha = (190 * titleA).toInt()
            c.drawText("SANJU SYSTEM X", w * 0.5f, h * 0.90f, p)
            p.textSize = h * 0.026f
            p.color = 0xFFFF334F.toInt()
            p.alpha = (170 * titleA).toInt()
            c.drawText("GAME SPACE", w * 0.5f, h * 0.94f, p)
        }
    }
}
