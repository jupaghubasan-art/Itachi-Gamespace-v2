package com.sanju.systemx.optimizer

import android.app.Activity
import android.os.Build
import android.view.WindowManager
import com.sanju.systemx.gamespace.GameInfo
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.resolution.ResolutionManager
import com.sanju.systemx.settings.GsLog
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.shizuku.ShizukuState
import kotlinx.coroutines.delay
import java.util.Locale

enum class RefreshTarget { MIN, MID, MAX, DEFAULT }

enum class OptimizationProfile(val title: String, val refresh: RefreshTarget, val scale: Float, val awake: Boolean) {
    LOW("LOW GRAPHICS", RefreshTarget.MIN, 0.6f, false),
    SMOOTH("SMOOTH GAMEPLAY", RefreshTarget.MAX, 0.8f, true),
    BALANCED("BALANCED", RefreshTarget.MID, 0.9f, false),
    PERFORMANCE("PERFORMANCE", RefreshTarget.MAX, 0.7f, true),
    DEFAULT("DEFAULT", RefreshTarget.DEFAULT, 1.0f, false);

    fun describe(): String {
        val res = if (scale < 1f) String.format(Locale.US, "%.1fx (needs Shizuku)", scale) else "native"
        return "Refresh: ${refresh.name} · Resolution: $res · Keep awake: ${if (awake) "YES" else "NO"}"
    }

    companion object {
        fun fromName(n: String): OptimizationProfile = values().firstOrNull { it.name == n } ?: BALANCED
    }
}

enum class Kind { OK, INFO, FAIL }
data class Step(val kind: Kind, val text: String) {
    val mark: String get() = when (kind) { Kind.OK -> "✓"; Kind.INFO -> "ℹ"; Kind.FAIL -> "✕" }
}

data class OptimizationResult(val steps: List<Step>) {
    val successful get() = steps.filter { it.kind == Kind.OK }
    val informational get() = steps.filter { it.kind == Kind.INFO }
    val failed get() = steps.filter { it.kind == Kind.FAIL }
}

/** Applies only what the device and Android really allow, and reports every outcome honestly. */
class OptimizationEngine(private val a: Activity, private val p: Prefs) {

    fun setAwake(on: Boolean) {
        if (on) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else a.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        p.setB("awake", on)
    }

    suspend fun run(profile: OptimizationProfile, game: GameInfo, onStep: (Step) -> Unit): OptimizationResult {
        val steps = mutableListOf<Step>()
        suspend fun add(k: Kind, t: String) {
            val s = Step(k, t); steps += s; onStep(s); delay(260)
        }
        GsLog.d("Optimizer", "profile=${profile.name} game=${game.pkg}")

        add(Kind.OK, "Device detected: ${Build.MANUFACTURER} ${Build.MODEL}")
        val sz = ShizukuBridge.state(a)
        val connected = sz == ShizukuState.CONNECTED
        if (connected) add(Kind.OK, "Shizuku connected")
        else add(Kind.INFO, "Shizuku not connected: running in limited mode. Connect Shizuku to use advanced optimization.")

        // Refresh rate: Android only lets an app request a mode for its own window.
        val rs = DisplayCtl.rates(a)
        if (profile.refresh == RefreshTarget.DEFAULT) {
            DisplayCtl.reset(a); p.setI("mode", 0)
            add(Kind.OK, "Refresh-rate preference reset to system default")
        } else if (rs.size < 2) {
            add(Kind.INFO, "Refresh rate: display reports only ${DisplayCtl.hz(a)} Hz")
        } else {
            val r = when (profile.refresh) { RefreshTarget.MIN -> rs.first(); RefreshTarget.MAX -> rs.last(); else -> rs[rs.size / 2] }
            DisplayCtl.apply(a, r.modeId); p.setI("mode", r.modeId)
            add(Kind.OK, "Refresh rate requested: ${r.hz} Hz (Game Space window; the game manages its own)")
        }

        // Resolution: system-wide, Shizuku only.
        if (!connected) {
            add(Kind.INFO, if (profile.scale < 1f) "Resolution skipped: requires Shizuku" else "Resolution unchanged")
        } else if (profile.scale >= 1f) {
            if (p.getB("res_modified", false)) {
                val r = ResolutionManager.reset(p)
                if (r.code == 0) add(Kind.OK, "Resolution restored to native") else add(Kind.FAIL, "Resolution restore failed: ${r.out}")
            } else add(Kind.INFO, "Resolution already native")
        } else {
            val base = ResolutionManager.physical()
            if (base == null) add(Kind.FAIL, "Resolution failed: could not read the screen size")
            else {
                val t = ResolutionManager.target(base, profile.scale)
                val r = ResolutionManager.apply(p, t)
                if (r.code == 0) add(Kind.OK, "Resolution: ${t.w} × ${t.h} (${String.format(Locale.US, "%.1f", profile.scale)}x)")
                else add(Kind.FAIL, "Resolution failed: ${r.out.ifBlank { "Shizuku command was rejected" }}")
            }
        }

        setAwake(profile.awake)
        add(Kind.OK, "Keep screen awake ${if (profile.awake) "on" else "off"} (Game Space)")
        p.setS("profile", profile.name)
        add(Kind.OK, "Game profile loaded: ${profile.title}")
        add(Kind.INFO, "GPU utilization: unavailable through public Android API")
        add(Kind.INFO, "External game FPS: unavailable")
        val installed = try { a.packageManager.getLaunchIntentForPackage(game.pkg) != null } catch (e: Exception) { false }
        if (installed) add(Kind.OK, "Game ready: ${game.label}") else add(Kind.FAIL, "Game cannot be launched: ${game.label}")
        return OptimizationResult(steps)
    }
}
