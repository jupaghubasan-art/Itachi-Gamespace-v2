package com.sanju.systemx.gamespace

import android.content.res.ColorStateList
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.ChipGroup
import com.sanju.systemx.device.DeviceInfoProvider
import com.sanju.systemx.optimizer.CapabilityDetector
import com.sanju.systemx.optimizer.OptimizationProfile
import com.sanju.systemx.optimizer.Support
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.resolution.ResolutionManager
import com.sanju.systemx.resolution.keepOrRevert
import com.sanju.systemx.shizuku.ShizukuState
import com.sanju.systemx.ui.Pal
import com.sanju.systemx.ui.box
import com.sanju.systemx.ui.btn
import com.sanju.systemx.ui.chips
import com.sanju.systemx.ui.components.AMBER
import com.sanju.systemx.ui.components.weight
import com.sanju.systemx.ui.dp
import com.sanju.systemx.ui.label
import com.sanju.systemx.ui.put
import kotlinx.coroutines.launch
import java.util.Locale

private fun f2(f: Float) = String.format(Locale.US, "%.2f", f)

/** PERFORMANCE: profile, refresh rate, resolution (Shizuku), resets and an honest capability list. */
fun GameSpaceActivity.performanceSection(): View {
    val act = this
    val connected = vm.shizuku.value == ShizukuState.CONNECTED
    val root = LinearLayout(this).apply { setPadding(dp(14), dp(6), dp(14), dp(10)) }
    val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    root.weight(left, 1f)
    root.weight(right, 1f, dp(12))

    // Profile
    var profile = OptimizationProfile.fromName(prefs.getS("profile", "BALANCED"))
    val pDesc = label(profile.describe(), 12f, Pal.sub)
    left.put(box("OPTIMIZATION PROFILE").apply {
        put(chips(OptimizationProfile.values().map { it.title }, profile.title) { t ->
            profile = OptimizationProfile.values().first { it.title == t }
            prefs.setS("profile", profile.name)
            pDesc.text = profile.describe()
            act.click(); act.updateStatusBars()
        }, 6)
        put(pDesc, 6)
        put(btn("RESET PERFORMANCE PROFILE", false) {
            act.lifecycleScope.launch {
                if (ask("Reset profile?", "Profile returns to BALANCED, the refresh-rate preference is cleared and keep-awake is turned off.", "RESET")) {
                    prefs.setS("profile", "BALANCED"); prefs.setI("mode", 0)
                    DisplayCtl.reset(act); engine.setAwake(false)
                    updateStatusBars(); renderSection()
                }
            }
        }, 8)
    }, 0)

    // Refresh rate
    val rates = DisplayCtl.rates(this)
    val note = label("", 12f, Pal.sub)
    left.put(box("REFRESH RATE").apply {
        put(label("Current: ${DisplayCtl.hz(act)} Hz   Available: " +
            (if (rates.isEmpty()) "unknown" else rates.joinToString(", ") { "${it.hz} Hz" }), 13f), 4)
        if (rates.size > 1) put(chips(rates.map { "${it.hz} Hz" }, rates.firstOrNull { it.hz == DisplayCtl.hz(act) }?.let { "${it.hz} Hz" }) { l ->
            val r = rates.first { "${it.hz} Hz" == l }
            DisplayCtl.apply(act, r.modeId); prefs.setI("mode", r.modeId); act.click()
            note.text = "Requested ${r.hz} Hz for the Game Space window. Games manage their own refresh rate."
        }, 6)
        else put(label("This display reports a single refresh rate.", 12f, Pal.sub), 4)
        put(note, 6)
    })

    // Capabilities (SUPPORTED / LIMITED / UNSUPPORTED)
    left.put(box("CAPABILITIES").apply {
        CapabilityDetector.detect(act, vm.shizuku.value, vm.graphics.value).forEach { c ->
            val col = when (c.support) { Support.SUPPORTED -> Pal.GREEN; Support.LIMITED -> AMBER; Support.UNSUPPORTED -> Pal.sub }
            put(label("${c.support.name}  ·  ${c.name}", 12f, col, true), 5)
            put(label(c.note, 11f, Pal.sub), 0)
        }
    })

    // Resolution
    val (sw, sh) = DeviceInfoProvider.screen(this)
    var base = ResolutionManager.Size(sw, sh)
    var pct = Math.round(prefs.getF("scale", 1f) * 100).coerceIn(50, 100)
    val info = label("", 13f)
    val out = label("", 12f, Pal.sub)
    lateinit var seek: SeekBar
    lateinit var group: ChipGroup
    fun refreshInfo() {
        val s = pct / 100f
        val t = ResolutionManager.target(base, s)
        info.text = "Native ${base.w} × ${base.h}\nScale ${f2(s)}x → ≈ ${t.w} × ${t.h}\nPixels rendered: ${Math.round(s * s * 100)}% of normal"
    }
    val presets = listOf(50, 60, 70, 80, 90, 100)
    val labels = presets.map { String.format(Locale.US, "%.1fx", it / 100f) }
    group = chips(labels, labels.firstOrNull { it == String.format(Locale.US, "%.1fx", pct / 100f) }, false) { l ->
        pct = presets[labels.indexOf(l)]; seek.progress = pct - 50; refreshInfo()
    }
    seek = SeekBar(this).apply {
        max = 50; progress = pct - 50
        progressTintList = ColorStateList.valueOf(Pal.RED)
        thumbTintList = ColorStateList.valueOf(Pal.RED)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                pct = p + 50; refreshInfo(); if (fromUser) group.clearCheck()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }
    refreshInfo()
    if (connected) act.lifecycleScope.launch { ResolutionManager.physical()?.let { base = it; refreshInfo() } }

    val applyBtn = btn("APPLY RESOLUTION") {
        prefs.setF("scale", pct / 100f)
        act.lifecycleScope.launch {
            val phys = ResolutionManager.physical()
            if (phys == null) { out.text = "✕ Resolution change failed.\nReason: could not read the screen size from Shizuku."; return@launch }
            val t = ResolutionManager.target(phys, pct / 100f)
            val ok = ask("Apply resolution ${f2(pct / 100f)}x?",
                "This may change display resolution.\n\nShizuku will run:\nwm size ${t.w}x${t.h}\n\nYou get 15 seconds afterwards to keep or revert.", "APPLY")
            if (!ok) return@launch
            val r = ResolutionManager.apply(prefs, t)
            if (r.code != 0) { out.text = "✕ Resolution change failed.\nReason: ${r.out.ifBlank { "Shizuku command was rejected." }}"; return@launch }
            out.text = "✓ Resolution set to ${t.w} × ${t.h}"
            keepOrRevert(prefs, out)
        }
    }
    val resetBtn = btn("RESET RESOLUTION", false) {
        act.lifecycleScope.launch {
            if (ask("Reset resolution?", "Shizuku will run:\nwm size reset", "RESET")) {
                val r = ResolutionManager.reset(prefs)
                out.text = if (r.code == 0) "✓ Native resolution restored." else "✕ Reset failed.\nReason: ${r.out}"
            }
        }
    }
    listOf(applyBtn, resetBtn).forEach { it.isEnabled = connected; it.alpha = if (connected) 1f else 0.4f }

    right.put(box("RESOLUTION").apply {
        put(group, 6)
        put(seek, 4)
        put(info, 8)
        if (!connected) put(label("Requires Shizuku. Tap CONNECT / CHECK SHIZUKU in the bottom bar.", 12f, AMBER, true), 8)
        put(applyBtn, 10)
        put(resetBtn, 8)
        put(out, 8)
    }, 0)
    return root
}

