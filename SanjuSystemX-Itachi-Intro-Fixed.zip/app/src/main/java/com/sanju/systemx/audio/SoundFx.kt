package com.sanju.systemx.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import com.sanju.systemx.R

/** UI sounds plus the five-second Itachi intro audio. */
class SoundFx(private val ctx: Context) {
    var enabled = true
    private val pool = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
    ).build()

    private val ids = HashMap<Int, Int>()
    private val loaded = HashSet<Int>()
    private var introPlayer: MediaPlayer? = null

    init {
        pool.setOnLoadCompleteListener { _, sid, status -> if (status == 0) loaded.add(sid) }
        listOf(R.raw.sfx_click, R.raw.sfx_whoosh, R.raw.sfx_boom, R.raw.sfx_boost, R.raw.sfx_ready)
            .forEach { ids[it] = pool.load(ctx, it, 1) }
    }

    fun play(res: Int, vol: Float = 0.7f) {
        if (!enabled) return
        val id = ids[res] ?: return
        if (id in loaded) pool.play(id, vol, vol, 1, 0, 1f)
    }

    /** Starts the supplied intro track from 0 and keeps it synchronized with the 5s animation. */
    fun playIntro() {
        stopIntro()
        if (!enabled) return
        introPlayer = MediaPlayer.create(ctx, R.raw.itachi_intro)?.apply {
            setVolume(1f, 1f)
            setOnCompletionListener {
                release()
                if (introPlayer === this) introPlayer = null
            }
            start()
        }
    }

    fun stopIntro() {
        introPlayer?.let {
            try { if (it.isPlaying) it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        introPlayer = null
    }

    fun release() {
        stopIntro()
        pool.release()
    }
}
