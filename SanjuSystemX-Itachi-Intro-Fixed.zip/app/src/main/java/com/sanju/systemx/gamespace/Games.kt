package com.sanju.systemx.gamespace

import android.content.Context
import android.content.Intent
import com.sanju.systemx.gaming.GameScanner
import com.sanju.systemx.settings.GsLog
import com.sanju.systemx.settings.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class GameInfo(val label: String, val pkg: String, val isMl: Boolean, val added: Boolean)

object GameRepository {
    private const val KEY = "added_games"

    /** Detected games (Android's game category + Mobile Legends by name) plus games the user added. */
    @Suppress("DEPRECATION")
    suspend fun load(ctx: Context, prefs: Prefs): List<GameInfo> = withContext(Dispatchers.IO) {
        val detected = GameScanner.scan(ctx, false).map { GameInfo(it.label, it.pkg, it.isMl, false) }
        val pm = ctx.packageManager
        val extra = prefs.getSet(KEY).filter { p -> detected.none { it.pkg == p } }.mapNotNull { pkg ->
            try { GameInfo(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(), pkg, false, true) }
            catch (e: Exception) { null }
        }
        detected + extra
    }

    suspend fun allLaunchable(ctx: Context): List<GameInfo> = withContext(Dispatchers.IO) {
        GameScanner.scan(ctx, true).map { GameInfo(it.label, it.pkg, it.isMl, false) }
    }

    fun add(prefs: Prefs, pkg: String) { if (GameLauncher.valid(pkg)) prefs.setSet(KEY, prefs.getSet(KEY) + pkg) }
    fun remove(prefs: Prefs, pkg: String) { prefs.setSet(KEY, prefs.getSet(KEY) - pkg) }
}

object GameLauncher {
    private val pkgRx = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$")
    fun valid(pkg: String) = pkgRx.matches(pkg)

    /** Returns null on success, or a readable error message. */
    fun launch(ctx: Context, pkg: String): String? {
        if (!valid(pkg)) return "Invalid package name."
        return try {
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "Game not installed or cannot be launched."
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            GsLog.d("GameLauncher", "launching $pkg")
            null
        } catch (e: Exception) { "Game cannot launch: ${e.javaClass.simpleName}" }
    }
}
